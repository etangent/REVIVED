from cmath import rect
from sys import platform
import pygame
import random
import math
import asyncio
from pygame.math import Vector2

SCALE = 1
WIDTH, HEIGHT = 1400, 900
robot_hitbox = 30

class Robot:
    def __init__(self, pos, theta=0, w=0, capacity = 70):
        self.pos = pos
        self.v = Vector2(0, 0)
        self.theta = theta
        self.w = w
        self.held = 8
        self.reload = 0
        self.intake_reload = 0
        self.capacity = capacity

    def update(self):
        self.v *= .9
        self.w *= .8
        self.pos += self.v
        self.theta += self.w
        self.reload = max(0, self.reload - 1/60)
        self.intake_reload = max(0, self.intake_reload - 1/60)

    def get_hitbox(self):
        h = robot_hitbox
        corners = []
        for x, y in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            corners.append(self.pos + Vector2(x, y).rotate(-self.theta))
        return corners

    def collide_walls(self):
        corners = self.get_hitbox()
        xs = [c.x for c in corners]
        ys = [c.y for c in corners]

        if min(xs) < Collisions.Field.VALID.left:
            self.pos.x += -min(xs) + Collisions.Field.VALID.left
            self.v.x = 0
        if max(xs) > Collisions.Field.VALID.right:
            self.pos.x -= max(xs) - Collisions.Field.VALID.right
            self.v.x = 0
        if min(ys) < Collisions.Field.VALID.top:
            self.pos.y += -min(ys) + Collisions.Field.VALID.top
            self.v.y = 0
        if max(ys) > Collisions.Field.VALID.bottom:
            self.pos.y -= max(ys) - Collisions.Field.VALID.bottom
            self.v.y = 0

    # obstacles should be (pos, radius)
    def align(self, desiredPos, desiredTheta, obstacles=[], maxSpeed=10000):
        to_goal = desiredPos - self.pos
        dist_to_goal = to_goal.length()
        
        if dist_to_goal > 1:
            attract = to_goal.normalize() * (min(dist_to_goal * 0.1, 3.0) - 0.2 * self.v.project((to_goal)).length())
        else:
            attract = Vector2(0, 0)

        repel = Vector2(0, 0)
        swerve = Vector2(0, 0)

        for o_pos, o_radius in obstacles:
            to_obs = self.pos - o_pos
            dist = to_obs.length()
            
            speed_buffer = self.v.length() * 20 
            safe_dist = o_radius + 45 + speed_buffer
            
            if 0 < dist < safe_dist:
                repel_magnitude = (1.0 / dist - 1.0 / safe_dist) * 400.0
                repel += to_obs.normalize() * repel_magnitude
                
                tangent = Vector2(-to_obs.y, to_obs.x).normalize()
                
                if self.v.dot(tangent) < 0:
                    tangent = -tangent
                if to_obs.normalize().dot(self.v.normalize()) > 0:
                    tangent = Vector2(0, 0)

                swerve += tangent * repel_magnitude * 1.5

        accel = attract + repel + swerve
        if accel.length() > 0:
            accel = accel.normalize() * min(accel.length(), 2.5)

        if self.v.length() > maxSpeed:
            accel = Vector2(0, 0)
        self.v += accel

        error = (desiredTheta - self.theta + 180) % 360 - 180
        alpha = 1.5 * error - 0.1 * self.w
        self.w += min(max(alpha, -2), 2)

        

    # returns the unit vector forward
    def forward(self):
        return Vector2(-1, 0).rotate(-self.theta)

    def collide_hub(self, hub):
        closest_x = max(hub.rect.left, min(self.pos.x, hub.rect.right))
        closest_y = max(hub.rect.top, min(self.pos.y, hub.rect.bottom))
        diff = self.pos - Vector2(closest_x, closest_y)
        distance = diff.length()
        if distance < robot_hitbox and distance > 0:
            overlap = robot_hitbox - distance
            self.pos += diff.normalize() * overlap
            self.v = Vector2(0, 0)

    def collide_other(self, other):
        self_corners = self.get_hitbox()
        other_corners = other.get_hitbox()
        min_overlap = float("inf")
        collision_normal = None

        for corners in (self_corners, other_corners):
            for i in range(len(corners)):
                edge = corners[(i + 1) % len(corners)] - corners[i]
                axis = Vector2(-edge.y, edge.x).normalize()
                self_projection = [corner.dot(axis) for corner in self_corners]
                other_projection = [corner.dot(axis) for corner in other_corners]
                overlap = min(max(self_projection), max(other_projection)) - max(
                    min(self_projection), min(other_projection)
                )
                if overlap <= 0:
                    return
                if overlap < min_overlap:
                    min_overlap = overlap
                    collision_normal = axis

        if (other.pos - self.pos).dot(collision_normal) < 0:
            collision_normal = -collision_normal

        correction = collision_normal * (min_overlap / 2)
        self.pos -= correction
        other.pos += correction

        relative_velocity = other.v - self.v
        velocity_along_normal = relative_velocity.dot(collision_normal)
        if velocity_along_normal < 0:
            impulse = -(1 + Collisions.BOUNCE) * velocity_along_normal / 2
            self.v -= impulse * collision_normal
            other.v += impulse * collision_normal

class Pumpkin:
    camera_height = 60**2 / 2

    def __init__(self, pos, v=None, v_up = 0, height = 0, r = 10):
        self.pos = pos
        self.v = v
        if v == None:
            self.v = Vector2(0, 0)
        self.height = height
        self.v_up = v_up
        self.r = r

    def update(self):
        if self.v.length() > 0: self.v = self.v.normalize() * min(15, self.v.length())
        self.pos += self.v
        self.height += self.v_up

        if self.height == 0:
            self.v *= .98
            return

        if self.height < 0:
            self.height = 0
            self.v_up = 0
            return

        self.v_up -= 1
        self.r = 10 * self.camera_height / (self.camera_height - self.height)

class Hub:
    def __init__(self, pos, width = 150, height = 150):
        self.pos = pos
        self.held = 0
        self.rect = pygame.Rect(pos.x - width/2, pos.y - height/2, width, height)

    hub = pygame.Rect(130, 130, 280, 480)

class Enemy_Hub:
    def __init__(self, pos, width = 150, height = 150):
        self.pos = pos
        self.held = 0
        self.rect = pygame.Rect(pos.x - width/2, pos.y - height/2, width, height)

    enemyhub = pygame.Rect(130, 130, 1000, 1000)

def shift(time):
    if (time < 20):
        return ("auto", math.ceil(20 - time))
    elif (time < 30):
        return ("transition", math.ceil(30 - time))
    elif (time < 55):
        return ("loser", math.ceil(55 - time))
    elif (time < 80):
        return ("winner", math.ceil(80 - time))
    elif (time < 105):
        return ("loser", math.ceil(105 - time))
    elif (time < 130):
        return ("winner", math.ceil(130 - time))
    elif (time < 160):
        return ("endgame", math.ceil(160 - time))
    else:
        return ("done", 0)

class Collisions:
    class Field:
        WALLS = [
            pygame.Rect(0,0,WIDTH,38),
            pygame.Rect(0,0,38,HEIGHT),
            pygame.Rect(0,HEIGHT-33,WIDTH,33),
            pygame.Rect(WIDTH-34,0,34,HEIGHT)
        ]
        VALID = pygame.Rect(38, 38, WIDTH-38-33, HEIGHT-33-33)
        HUB = [ # not implemented, not super needed?
            pygame.Rect(250,382,154,140),
            pygame.Rect(1000,382,154,140)
        ]
    BOUNCE = 0.15
    SMALL = 1e-4
    @staticmethod
    def pumpkins(objects):
        for i in range(len(objects)):
            a = objects[i]
            for j in range(i + 1, len(objects)):
                b = objects[j]
                if abs(a.height - b.height) > a.r + b.r: continue
                d = b.pos - a.pos
                distanceSquared = d.length_squared()

                if distanceSquared < Collisions.SMALL:
                    normal = Vector2(1, 0)
                    dist = 0.0
                else:
                    dist = math.sqrt(distanceSquared)
                    normal = d/dist

                minDist = a.r + b.r
                if dist >= minDist: continue
                rvel = b.v - a.v
                rvelNorm = rvel.dot(normal)
                if rvelNorm < 0:
                    impulse = -(1 + Collisions.BOUNCE) * rvelNorm / 2
                    a.v -= impulse * normal
                    b.v += impulse * normal

                overlap = minDist - dist
                if dist < Collisions.SMALL: correction = normal * (overlap / 2)
                else: correction = normal * (overlap / 2)
                a.pos -= correction
                b.pos += correction
    @staticmethod
    def robotPumpkins(robot, pumpkins):
        robor = robot_hitbox
        right = Vector2(1, 0).rotate(-robot.theta)
        up = Vector2(0, 1).rotate(-robot.theta)

        for p in pumpkins:
            if p.height > 0:
                continue

            relative = p.pos - robot.pos
            localX = relative.dot(right)
            localY = relative.dot(up)

            closestX = max(-robor, min(robor, localX))
            closestY = max(-robor, min(robor, localY))

            closestLocal = Vector2(closestX, closestY)

            closestWord = (
                robot.pos
                + right * closestLocal.x
                + up * closestLocal.y
            )

            diff = p.pos - closestWord
            distanceSquared = diff.length_squared()

            if distanceSquared >= p.r**2:
                continue

            if distanceSquared > Collisions.SMALL:
                distance = math.sqrt(distanceSquared)
                normal = diff / distance
                penetration = p.r - distance
            else:
                distX = robor-abs(localX)
                distY = robor-abs(localY)

                if distX < distY:
                    localNormal = Vector2(
                        1 if localX >= 0 else -1,
                        0
                    )
                    penetration = p.r + distX
                else:
                    localNormal = Vector2(
                        0,
                        1 if localY >= 0 else -1
                    )
                    penetration = p.r + distY

                normal = (
                    right * localNormal.x
                    + up * localNormal.y
                )
            p.pos += normal * penetration
            velocity_toward_robot = p.v.dot(normal)

            if velocity_toward_robot < 0:
                p.v += velocity_toward_robot * normal

    @staticmethod
    def pumpkinWalls(pumpkins, walls):
        for p in pumpkins:
            for wall in walls:
                closestX = max(wall.left, min(p.pos.x, wall.right))
                closestY = max(wall.top, min(p.pos.y, wall.bottom))

                diff = p.pos - Vector2(closestX, closestY)
                distSq = diff.length_squared()

                if distSq >= p.r**2:
                    continue

                if distSq > Collisions.SMALL:
                    dist = math.sqrt(distSq)
                    normal = diff / dist
                    penetration = p.r - dist
                else:
                    distances = [
                        (p.pos.x - wall.left, Vector2(-1, 0)),
                        (wall.right - p.pos.x, Vector2(1, 0)),
                        (p.pos.y - wall.top, Vector2(0, -1)),
                        (wall.bottom - p.pos.y, Vector2(0, 1)),
                    ]
                    dist, normal = min(distances, key=lambda item: item[0])
                    penetration = p.r + dist

                p.pos += normal * penetration

                velocity_toward_wall = p.v.dot(normal)
                if velocity_toward_wall < 0:
                    p.v -= 2 * velocity_toward_wall * normal

async def main():
    pygame.init()
    _screen = pygame.display.set_mode((int(WIDTH*SCALE), int(HEIGHT*SCALE)), pygame.SCALED)
    screen = pygame.Surface((WIDTH, HEIGHT))
    clock = pygame.time.Clock()

    player_image = pygame.image.load("assets/player.png").convert_alpha()
    player_image = pygame.transform.scale(player_image, (60, 60))
    player_image = pygame.transform.rotate(player_image, 180)
    enemy_image = pygame.image.load("assets/enemy.png").convert_alpha()
    enemy_image = pygame.transform.scale(enemy_image, (60, 60))


    bg_image = pygame.image.load("assets/field.png").convert_alpha()
    bg_image = pygame.transform.scale(bg_image, (WIDTH, HEIGHT))

    player = Robot(Vector2(200, 100))
    enemy = Robot(Vector2(WIDTH - 200, HEIGHT - 100))

    player_hub = Hub(Vector2(WIDTH / 4 - 20, HEIGHT/2))
    enemy_hub = Hub(Vector2(3* WIDTH / 4 + 20, HEIGHT/2))

    pumpkins = []
    for i in range(-4, 5):
        for j in range(-10, 11):
            pumpkins.append(Pumpkin(Vector2(WIDTH/2 + i * 24, HEIGHT/2 + j * 24)))


    target = Vector2(WIDTH/4, HEIGHT/2)

    timer = 0
    player_score = 0
    enemy_score = 0
    running = True
    player_auto_status = None
    enemy_auto_status = None
    while running and timer < 160:
        if abs(timer - 20) < .25:
            if player_score > enemy_score:
                player_auto_status = "winner"
                enemy_auto_status = "loser"
            else:
                player_auto_status = "loser"
                enemy_auto_status = "winner"

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()      

        keys = pygame.key.get_pressed()
        val = 2
        if ((keys[pygame.K_a] or keys[pygame.K_d]) and (keys[pygame.K_w] or keys[pygame.K_s])):
            val = math.sqrt(2)
        if keys[pygame.K_j] or keys[pygame.K_l]:
            val *= .8
        if keys[pygame.K_a]:
            player.v.x -= val
        if keys[pygame.K_d]:
            player.v.x += val
        if keys[pygame.K_w]:
            player.v.y -= val
        if keys[pygame.K_s]:
            player.v.y += val
        if keys[pygame.K_j]:
            player.w += 2
        if keys[pygame.K_l]:
            player.w -= 2
        player.update()
        player.collide_walls()

        if keys[pygame.K_SPACE] and player.held > 0 and player.reload == 0:
            if player.pos.x > WIDTH / 4:
                if player.pos.y < HEIGHT / 2:
                    target = Vector2(WIDTH / 4, HEIGHT / 4)
                else:
                    target = Vector2(WIDTH / 4, 3 * HEIGHT / 4)
            else:
                target = Vector2(player_hub.pos)

            v_up = random.randint(25, 35)
            tof = 2 * v_up
            v = (target - player.pos).normalize() * target.distance_to(player.pos) / tof
            v += .05 * player.v
            pumpkins.append(Pumpkin(player.pos.copy(), v, v_up))
            player.reload = .1
            player.held -= 1

        if player_hub.held > 0 and random.randint(0, 6 - min(6, player_hub.held)) == 0:
            pumpkins.append(Pumpkin(player_hub.pos + Vector2(80, 0), Vector2(1, 0).rotate(random.uniform(-45, 45)) * random.uniform(3, 10)))
            player_hub.held -= 1
        if enemy_hub.held > 0 and random.randint(0, 6 - min(6, enemy_hub.held)) == 0:
            pumpkins.append(Pumpkin(enemy_hub.pos - Vector2(80, 0), Vector2(-1, 0).rotate(random.uniform(-45, 45)) * random.uniform(3, 10)))
            enemy_hub.held -= 1
        if shift(timer + 2)[0] != player_auto_status and (enemy.held == enemy.capacity or (enemy.held > 0 and enemy.pos.x > enemy_hub.pos.x + 100)):
            enemy.align(enemy_hub.pos + Vector2(200, 0), enemy.theta, [(player_hub.pos, 75), (enemy_hub.pos, 75)])
            if enemy.reload == 0 and enemy.pos.x > enemy_hub.pos.x + 100:
                target = Vector2(enemy_hub.pos)
                v_up = random.randint(25, 35)
                tof = 2 * v_up
                v = (target - enemy.pos).normalize() * target.distance_to(enemy.pos) / tof
                v += .05 * enemy.v
                pumpkins.append(Pumpkin(enemy.pos.copy(), v, v_up))
                enemy.reload = .1
                enemy.held -= 1
        elif enemy.held < enemy.capacity and pumpkins:
            closest = min(pumpkins, key=lambda x: .001 * x.pos.distance_to(enemy.pos) + 100000 * x.height - 1 * (-enemy.forward()).dot((x.pos - enemy.pos).normalize() if x.pos != enemy.pos else Vector2(0,0)))

            diffVector = closest.pos - enemy.pos
            dist = diffVector.length()

            if dist > 0:
                target_theta = -math.degrees(math.atan2(diffVector.y, diffVector.x))
            else:
                target_theta = enemy.theta

            enemy.align(closest.pos, target_theta, [(player_hub.pos, 75), (enemy_hub.pos, 75)])            
        else:
            enemy.align(player.pos, enemy.theta + 1, [(player_hub.pos, 75), (enemy_hub.pos, 75)])

        enemy.update()
        enemy.collide_walls()
        player.collide_other(enemy)
        taken = []
        for p in pumpkins:
            if enemy.held == enemy.capacity or enemy.intake_reload >= .15:
                break
            if p.v_up == 0 and (-1 * enemy.forward()).dot((p.pos - enemy.pos).normalize()) > .7 and p.pos.distance_to(enemy.pos - enemy.forward()) < 4 * p.r:
                taken.append(p)
                enemy.held+=1
                enemy.intake_reload += .03
        for t in taken:
            pumpkins.remove(t)

        if keys[pygame.K_LSHIFT]:
            taken = []
            for p in pumpkins:
                if player.held == player.capacity or player.intake_reload >= .15:
                    break
                if p.v_up == 0 and (-1 * player.forward()).dot((p.pos - player.pos).normalize()) > .7 and p.pos.distance_to(player.pos - player.forward()) < 4 * p.r:
                    taken.append(p)
                    player.held+=1
                    player.intake_reload += .03
            for t in taken:
                pumpkins.remove(t)


        if player.collide_hub(player_hub) == True:
            if velocity_y > 0:
                y = platform.top - 50
                velocity_y = 0
                on_ground = True
            elif velocity_y < 0:
                y = platform.bottom
                velocity_y = 0

        if player.collide_hub(enemy_hub) == True:
                    if velocity_y > 0:
                        y = platform.top - 50
                        velocity_y = 0
                        on_ground = True
                    elif velocity_y < 0:
                        y = platform.bottom
                        velocity_y = 0


        taken = []
        for p in pumpkins:
            p.update()

            if player_hub.pos.distance_to(p.pos) < 75 and p.height < 5:
                player_hub.held += 1
                taken.append(p)
                if shift(timer)[0] != enemy_auto_status:
                    player_score += 1
            if enemy_hub.pos.distance_to(p.pos) < 75 and p.height < 5:
                enemy_hub.held += 1
                taken.append(p)
                if shift(timer)[0] != player_auto_status:
                    enemy_score += 1
        for t in taken:
            pumpkins.remove(t)

        Collisions.pumpkins(pumpkins)
        Collisions.robotPumpkins(player, pumpkins)
        Collisions.robotPumpkins(enemy, pumpkins)
        Collisions.pumpkinWalls(pumpkins, Collisions.Field.WALLS)

        screen.fill((0,0,0))
        screen.blit(bg_image, (0, 0))

        player_rotated = pygame.transform.rotate(player_image, player.theta)
        screen.blit(player_rotated, player_rotated.get_rect(center=player.pos))
        enemy_rotated = pygame.transform.rotate(enemy_image, enemy.theta)
        screen.blit(enemy_rotated, enemy_rotated.get_rect(center=enemy.pos))

        for p in pumpkins:
            pygame.draw.circle(screen, (254, 117, 24), p.pos, p.r)

        font = pygame.font.Font(None, 50)
        text_surface = font.render(str(player.held) + "/" + str(player.capacity) + " held", False, (255, 255, 255))
        screen.blit(text_surface, (10, HEIGHT - 50))
        text_surface = font.render("Your Score: " + str(player_score), False, (255, 255, 255))
        screen.blit(text_surface, (10, 0))
        text_surface = font.render("Enemy Score: " + str(enemy_score), False, (255, 255, 255))
        screen.blit(text_surface, (WIDTH - 300, 0))
        curr_shift = shift(timer)[0]
        if curr_shift == "winner" or curr_shift == "loser":
            if player_auto_status == curr_shift:
                curr_shift = "player"
            if enemy_auto_status == curr_shift:
                curr_shift = "enemy"
        text_surface = font.render("Shift: " + curr_shift + ", " + str(shift(timer)[1]), False, (255, 255, 255))
        screen.blit(text_surface, (WIDTH - 400, HEIGHT - 50))

        _screen.blit(pygame.transform.scale(screen, _screen.get_size()), (0,0))
        pygame.display.flip()

        clock.tick(60)
        timer += 1/60
        await asyncio.sleep(0)

    screen.fill((0, 0, 0))
    winner = "player"
    if enemy_score > player_score:
        winner = "enemy"
    font = pygame.font.Font(None, 100)
    text_surface = font.render(winner + " wins!", False, (255, 255, 255))
    screen.blit(text_surface, (WIDTH/2 - 200, HEIGHT / 2))
    text_surface = font.render("Your Score: " + str(player_score), False, (255, 255, 255))
    screen.blit(text_surface, (10, 0))
    text_surface = font.render("Enemy Score: " + str(enemy_score), False, (255, 255, 255))  
    screen.blit(text_surface, (WIDTH - 600, 0))
    _screen.blit(pygame.transform.scale(screen, _screen.get_size()), (0, 0))
    pygame.display.flip()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()      
            clock.tick(60)
            await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())